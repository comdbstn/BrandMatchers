export { default as Hero } from './Hero';
export { default as SearchSection } from './SearchSection';
export { default as TeamSection } from './TeamSection';
export { default as PartnerSection } from './PartnerSection';
export { default as TestimonialSection } from './TestimonialSection';